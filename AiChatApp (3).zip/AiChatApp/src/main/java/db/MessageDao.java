package db;

import com.example.aichat.model.Message;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MessageDao {

    public void insert(Message msg) {
        String sql = "INSERT INTO messages(role, content) VALUES (?, ?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, msg.getRole());
            ps.setString(2, msg.getContent());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Insert failed", e);
        }
    }

    public List<Message> findAll() {
        List<Message> list = new ArrayList<>();
        String sql = "SELECT id, role, content, created_at FROM messages ORDER BY id ASC";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Message(
                        rs.getInt("id"),
                        rs.getString("role"),
                        rs.getString("content"),
                        rs.getString("created_at")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Query failed", e);
        }
        return list;
    }
}
