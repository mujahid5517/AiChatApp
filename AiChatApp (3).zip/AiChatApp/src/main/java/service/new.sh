ollama run llama2
ollama run mistral