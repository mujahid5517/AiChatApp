package com.example.aichat.model;

public class Message {
    private Integer id;
    private String role;   // "user" or "assistant"
    private String content;
    private String createdAt;

    public Message(Integer id, String role, String content, String createdAt) {
        this.id = id;
        this.role = role;
        this.content = content;
        this.createdAt = createdAt;
    }

    public Message(String role, String content) {
        this(null, role, content, null);
    }

    public Integer getId() { return id; }
    public String getRole() { return role; }
    public String getContent() { return content; }
    public String getCreatedAt() { return createdAt; }
}
