package com.example.aichat.db;

import com.example.aichat.model.Message;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MessageDao {

    public void insert(Message msg, int sessionId) {
        String sql = "INSERT INTO messages(role, content, session_id) VALUES (?, ?, ?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, msg.getRole());
            ps.setString(2, msg.getContent());
            ps.setInt(3, sessionId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Insert message failed", e);
        }
    }

    public List<Message> findBySessionId(int sessionId) {
        List<Message> list = new ArrayList<>();
        String sql = "SELECT id, role, content, created_at FROM messages WHERE session_id = ? ORDER BY id ASC";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sessionId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Message(
                        rs.getInt("id"),
                        rs.getString("role"),
                        rs.getString("content"),
                        rs.getString("created_at")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Query for messages by session failed", e);
        }
        return list;
    }

    public void deleteBySessionId(int sessionId) {
        String sql = "DELETE FROM messages WHERE session_id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sessionId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete messages by session", e);
        }
    }
}
