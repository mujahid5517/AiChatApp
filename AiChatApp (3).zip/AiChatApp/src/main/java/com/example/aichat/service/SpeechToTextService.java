package com.example.aichat.service;

import ai.picovoice.leopard.Leopard;
import ai.picovoice.leopard.LeopardException;
import ai.picovoice.leopard.LeopardTranscript;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;

public class SpeechToTextService {

    private final String accessKey = "E38vSyTNCK17NkE4xCOxFJlh052i/wB0EjgTl8BI3wHtthJFy7G+Xw==";
    private TargetDataLine microphone;
    private boolean isRecording = false;
    private Path tempAudioFile;

    public void startRecording() throws IOException, LineUnavailableException {
        if (isRecording) return;

        AudioFormat format = new AudioFormat(16000, 16, 1, true, false);
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);

        if (!AudioSystem.isLineSupported(info)) {
            throw new LineUnavailableException("Microphone not supported for the required format.");
        }

        microphone = (TargetDataLine) AudioSystem.getLine(info);
        microphone.open(format);
        microphone.start();
        isRecording = true;

        tempAudioFile = Files.createTempFile("recording-", ".wav");

        new Thread(() -> {
            try {
                AudioSystem.write(new AudioInputStream(microphone), AudioFileFormat.Type.WAVE, tempAudioFile.toFile());
            } catch (IOException e) {
                System.err.println("Error writing audio to file: " + e.getMessage());
            }
        }).start();
    }

    public CompletableFuture<String> stopRecordingAndTranscribe() {
        if (!isRecording) {
            return CompletableFuture.completedFuture("");
        }

        isRecording = false;
        microphone.stop();
        microphone.close();

        return CompletableFuture.supplyAsync(() -> {
            try {
                Leopard leopard = new Leopard.Builder()
                        .setAccessKey(accessKey)
                        .build();

                LeopardTranscript result = leopard.processFile(tempAudioFile.toString());
                leopard.delete();
                Files.delete(tempAudioFile); // Clean up the temp file

                return result.getTranscriptString(); // Corrected method name
            } catch (LeopardException | IOException e) {
                System.err.println("Error during transcription: " + e.getMessage());
                return "Error during transcription.";
            }
        });
    }
}
