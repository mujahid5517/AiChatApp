package com.example.aichat.controller;

import com.example.aichat.model.User;
import com.example.aichat.service.AuthService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class LoginController {
    @FXML private TextField identifierField;
    @FXML private PasswordField passwordField;
    @FXML private Label messageLabel;

    private final AuthService authService = new AuthService();
    private Stage stage; // Reference to the login stage
    private ChatController chatController; // Reference to the main chat controller

    // To pass the stage to this controller
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    // To pass the ChatController to this controller
    public void setChatController(ChatController chatController) {
        this.chatController = chatController;
    }

    @FXML
    public void onLogin() {
        String identifier = identifierField.getText();
        String password = passwordField.getText();

        if (identifier.isEmpty() || password.isEmpty()) {
            messageLabel.setText("Please enter username/email and password.");
            return;
        }

        User user = authService.loginUser(identifier, password);
        if (user != null) {
            messageLabel.setText("Login successful!");
            messageLabel.setStyle("-fx-text-fill: green;");
            if (chatController != null) {
                chatController.onUserLoggedIn(user);
            }
            if (stage != null) {
                stage.close();
            }
        } else {
            messageLabel.setText("Login failed. Invalid credentials.");
            messageLabel.setStyle("-fx-text-fill: red;");
        }
    }

    @FXML
    public void onRegister() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/aichat/view/RegisterView.fxml"));
            Parent root = fxmlLoader.load();
            RegisterController registerController = fxmlLoader.getController();
            registerController.setChatController(chatController); // Pass chatController to RegisterController

            Stage registerStage = new Stage();
            registerStage.initModality(Modality.APPLICATION_MODAL);
            registerStage.setTitle("Create Account");
            registerStage.setScene(new Scene(root));
            registerStage.showAndWait();
        } catch (IOException e) {
            System.err.println("Failed to load RegisterView.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
