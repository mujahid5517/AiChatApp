package com.example.aichat.controller;

import com.example.aichat.model.User;
import com.example.aichat.service.AuthService;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegisterController {
    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Label messageLabel;

    private final AuthService authService = new AuthService();
    private ChatController chatController; // Reference to the main chat controller

    // Method to set the reference to the main chat controller
    public void setChatController(ChatController chatController) {
        this.chatController = chatController;
    }

    @FXML
    public void onRegister() {
        String username = usernameField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();

        if (!password.equals(confirmPassword)) {
            messageLabel.setText("Passwords do not match!");
            return;
        }

        // Attempt to register the user
        if (authService.registerUser(username, email, password)) {
            messageLabel.setText("Registration successful!");
            messageLabel.setStyle("-fx-text-fill: green;");

            // Automatically log in the user after successful registration
            User registeredUser = authService.loginUser(email, password); // Use email for login
            if (registeredUser != null && chatController != null) {
                chatController.onUserLoggedIn(registeredUser);
                // Close the registration window
                ((Stage) messageLabel.getScene().getWindow()).close();
            } else {
                System.err.println("Error: Registered user could not be logged in automatically.");
            }
        } else {
            // Error messages are already printed by AuthService
            messageLabel.setText("Registration failed. Check console for details.");
            messageLabel.setStyle("-fx-text-fill: red;");
        }
    }
}
