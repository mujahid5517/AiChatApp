package com.example.aichat.db;

import com.example.aichat.model.ChatSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChatSessionDao {

    public ChatSession create(ChatSession session) {
        String sql = "INSERT INTO chat_sessions(title, user_id) VALUES (?, ?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, session.getTitle());
            if (session.getUserId() != null) {
                ps.setInt(2, session.getUserId());
            } else {
                ps.setNull(2, Types.INTEGER);
            }
            ps.executeUpdate();

            ResultSet generatedKeys = ps.getGeneratedKeys();
            if (generatedKeys.next()) {
                session.setId(generatedKeys.getInt(1));
            }
            return session;
        } catch (SQLException e) {
            throw new RuntimeException("Create chat session failed", e);
        }
    }

    public List<ChatSession> findAll(Integer userId) {
        List<ChatSession> list = new ArrayList<>();
        String sql = "SELECT id, title, user_id, created_at FROM chat_sessions WHERE user_id = ? ORDER BY created_at DESC";
        if (userId == null) { // For guest users
            sql = "SELECT id, title, user_id, created_at FROM chat_sessions WHERE user_id IS NULL ORDER BY created_at DESC";
        }
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            if (userId != null) {
                ps.setInt(1, userId);
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ChatSession(
                        rs.getInt("id"),
                        rs.getString("title"),
                        (Integer) rs.getObject("user_id"), // Handle possible NULL
                        rs.getString("created_at")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Query for chat sessions failed", e);
        }
        return list;
    }

    public List<ChatSession> searchByTitle(String title, Integer userId) {
        List<ChatSession> list = new ArrayList<>();
        String sql = "SELECT id, title, user_id, created_at FROM chat_sessions WHERE title LIKE ? AND user_id = ? ORDER BY created_at DESC";
        if (userId == null) { // For guest users
            sql = "SELECT id, title, user_id, created_at FROM chat_sessions WHERE title LIKE ? AND user_id IS NULL ORDER BY created_at DESC";
        }
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + title + "%");
            if (userId != null) {
                ps.setInt(2, userId);
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ChatSession(
                        rs.getInt("id"),
                        rs.getString("title"),
                        (Integer) rs.getObject("user_id"), // Handle possible NULL
                        rs.getString("created_at")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Search for chat sessions by title failed", e);
        }
        return list;
    }

    public void delete(int sessionId) {
        String sql = "DELETE FROM chat_sessions WHERE id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sessionId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Delete chat session failed", e);
        }
    }
}
