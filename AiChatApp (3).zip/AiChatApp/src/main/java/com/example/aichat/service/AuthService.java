package com.example.aichat.service;

import com.example.aichat.db.UserDao;
import com.example.aichat.model.User;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AuthService {
    private final UserDao userDao = new UserDao();

    // Basic email validation regex
    private static final Pattern VALID_EMAIL_ADDRESS_REGEX =
            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

    public boolean registerUser(String username, String email, String password) {
        // Validate inputs
        if (username == null || username.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            password == null || password.isEmpty()) {
            System.err.println("Registration failed: All fields are required.");
            return false;
        }

        if (!isValidEmail(email)) {
            System.err.println("Registration failed: Invalid email format.");
            return false;
        }

        if (password.length() < 6) {
            System.err.println("Registration failed: Password must be at least 6 characters long.");
            return false;
        }

        // Check if username or email already exists
        if (userDao.findByUsername(username) != null) {
            System.err.println("Registration failed: Username already exists.");
            return false;
        }
        if (userDao.findByEmail(email) != null) {
            System.err.println("Registration failed: Email already exists.");
            return false;
        }

        // Hash password
        String hashedPassword = hashPassword(password);
        if (hashedPassword == null) {
            System.err.println("Registration failed: Could not hash password.");
            return false;
        }

        // Create and insert user
        User newUser = new User(username, email, hashedPassword);
        try {
            userDao.insert(newUser);
            System.out.println("User registered successfully: " + username);
            return true;
        } catch (RuntimeException e) {
            System.err.println("Registration failed: Database error - " + e.getMessage());
            return false;
        }
    }

    public User loginUser(String identifier, String password) {
        User user = null;
        if (isValidEmail(identifier)) {
            user = userDao.findByEmail(identifier);
        } else {
            user = userDao.findByUsername(identifier);
        }

        if (user != null && verifyPassword(password, user.getPasswordHash())) {
            System.out.println("User logged in successfully: " + user.getUsername());
            return user;
        } else {
            System.err.println("Login failed: Invalid credentials for " + identifier);
            return null;
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Error hashing password: " + e.getMessage());
            return null;
        }
    }

    private boolean verifyPassword(String rawPassword, String hashedPassword) {
        String hashedRawPassword = hashPassword(rawPassword);
        return hashedRawPassword != null && hashedRawPassword.equals(hashedPassword);
    }

    private boolean isValidEmail(String email) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(email);
        return matcher.matches();
    }
}
