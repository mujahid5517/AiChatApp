package com.example.aichat.service;

import com.example.aichat.model.Message;
import com.example.aichat.util.JsonUtil;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ChatService {
    private SettingsManager settingsManager;

    public ChatService(SettingsManager settingsManager) {
        this.settingsManager = settingsManager;
    }

    public List<String> listOllamaModels() {
        String ollamaHost = settingsManager.getProperty("ollamaHost");
        if (ollamaHost == null || ollamaHost.isEmpty()) {
            return Collections.singletonList("Ollama host not configured");
        }

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(ollamaHost + "/api/tags"))
                    .timeout(Duration.ofSeconds(10))
                    .header("Accept", "application/json")
                    .GET()
                    .build();

            HttpResponse<String> response = HttpClientProvider.get()
                    .send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                Map<String, Object> parsed = JsonUtil.fromJson(response.body());
                List<Map<String, Object>> models = (List<Map<String, Object>>) parsed.get("models");
                if (models != null) {
                    return models.stream()
                            .map(model -> (String) model.get("name"))
                            .collect(Collectors.toList());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.singletonList("Failed to connect to Ollama");
        }
        return Collections.emptyList();
    }

    public String ask(List<Message> history, String currentPrompt, byte[] imageBytes, String mimeType) throws Exception {
        String provider = settingsManager.getProperty("provider");
        String model = settingsManager.getProperty("model");
        String apiKey = null;
        String apiUrl;
        String json;

        if ("Stability.ai".equalsIgnoreCase(provider)) {
            return "Error: Stability.ai is an image generation provider. Please select a text generation provider in the settings.";
        }

        // Check for image input compatibility
        if (imageBytes != null && mimeType != null) {
            if ("Groq".equals(provider) || "Ollama".equals(provider)) {
                return "Error: The selected provider (" + provider + ") does not support image input. Please choose a multimodal provider like Google or OpenRouter (with a compatible model).";
            }
            // Add more specific checks for OpenRouter models if needed
            if ("OpenRouter".equals(provider) && !model.contains("gpt-4o") && !model.contains("vision") && !model.contains("gemini")) {
                return "Error: The selected OpenRouter model (" + model + ") may not support image input. Please select a multimodal model like 'openai/gpt-4o' or 'google/gemini-pro'.";
            }
        }


        switch (provider) {
            case "Google": {
                apiKey = settingsManager.getProperty("googleApiKey");
                if (apiKey == null || apiKey.isEmpty()) {
                    return "Error: Google API Key not configured. Please add it in the settings.";
                }
                apiUrl = "https://generativelanguage.googleapis.com/v1/models/" + model + ":generateContent?key=" + apiKey;

                // Build Google-specific payload
                List<Map<String, Object>> contents = new ArrayList<>();
                for (Message msg : history) {
                    String role = msg.getRole().equals("assistant") ? "model" : msg.getRole();
                    contents.add(Map.of("role", role, "parts", List.of(Map.of("text", msg.getContent()))));
                }

                // Add current prompt and image (if present)
                List<Map<String, String>> parts = new ArrayList<>();
                parts.add(Map.of("text", currentPrompt));
                if (imageBytes != null && mimeType != null) {
                    parts.add(Map.of("inline_data", Map.of(
                            "mime_type", mimeType,
                            "data", Base64.getEncoder().encodeToString(imageBytes)
                    ).toString()));
                }
                contents.add(Map.of("role", "user", "parts", parts));

                Map<String, Object> body = Map.of("contents", contents);
                json = JsonUtil.toJson(body);
                break;
            }
            case "OpenRouter":
            case "Groq":
            case "Ollama": {
                // Build OpenAI-compatible payload
                List<Object> messages = new ArrayList<>();
                for (Message msg : history) {
                    messages.add(Map.of("role", msg.getRole(), "content", msg.getContent()));
                }

                // Add current prompt and image (if present)
                List<Object> contentList = new ArrayList<>();
                contentList.add(Map.of("type", "text", "text", currentPrompt));
                if (imageBytes != null && mimeType != null) {
                    contentList.add(Map.of(
                            "type", "image_url",
                            "image_url", Map.of("url", "data:" + mimeType + ";base64," + Base64.getEncoder().encodeToString(imageBytes))
                    ));
                }
                messages.add(Map.of("role", "user", "content", contentList));

                Map<String, Object> body = Map.of("model", model, "messages", messages);
                json = JsonUtil.toJson(body);

                if ("OpenRouter".equals(provider)) {
                    apiKey = settingsManager.getProperty("openRouterKey");
                    if (apiKey == null || apiKey.isEmpty()) {
                        return "Error: OpenRouter API Key not configured.";
                    }
                    apiUrl = "https://openrouter.ai/api/v1/chat/completions";
                } else if ("Groq".equals(provider)) {
                    apiKey = settingsManager.getProperty("groqKey");
                    if (apiKey == null || apiKey.isEmpty()) {
                        return "Error: Groq API Key not configured.";
                    }
                    apiUrl = "https://api.groq.com/openai/v1/chat/completions";
                } else { // Ollama
                    String ollamaHost = settingsManager.getProperty("ollamaHost");
                    if (ollamaHost == null || ollamaHost.isEmpty()) {
                        return "Error: Ollama host not configured.";
                    }
                    apiUrl = ollamaHost + "/api/chat";
                }
                break;
            }
            default:
                return "Error: Unsupported provider for text generation.";
        }

        HttpRequest.Builder requestBuilder = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .timeout(Duration.ofSeconds(60))
                .header("Content-Type", "application/json");

        if (apiKey != null && !apiKey.isEmpty()) {
            if (!"Google".equals(provider)) {
                requestBuilder.header("Authorization", "Bearer " + apiKey);
            }
        }

        requestBuilder.POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8));

        HttpResponse<String> res = HttpClientProvider.get()
                .send(requestBuilder.build(), HttpResponse.BodyHandlers.ofString());

        if (res.statusCode() >= 200 && res.statusCode() < 300) {
            Map<String, Object> parsed = JsonUtil.fromJson(res.body());
            if ("Google".equals(provider)) {
                var candidates = (List<?>) parsed.get("candidates");
                if (candidates != null && !candidates.isEmpty()) {
                    var first = (Map<String, Object>) candidates.get(0);
                    var contentMap = (Map<String, Object>) first.get("content");
                    var parts = (List<?>) contentMap.get("parts");
                    if (parts != null && !parts.isEmpty()) {
                        var firstPart = (Map<String, Object>) parts.get(0);
                        return (String) firstPart.get("text");
                    }
                }
            } else if ("OpenRouter".equals(provider) || "Groq".equals(provider) || "Ollama".equals(provider)) {
                var choices = (List<?>) parsed.get("choices");
                if (choices != null && !choices.isEmpty()) {
                    var firstChoice = (Map<String, Object>) choices.get(0);
                    var message = (Map<String, Object>) firstChoice.get("message");
                    return (String) message.get("content");
                }
            }
            return "(no text)";
        } else {
            throw new RuntimeException(provider + " API error: " + res.statusCode() + " - " + res.body());
        }
    }

    public String createImage(String prompt) throws Exception {
        String provider = settingsManager.getProperty("provider");
        String model = settingsManager.getProperty("model");
        String apiKey = settingsManager.getProperty("stabilityApiKey");

        if (!"Stability.ai".equalsIgnoreCase(provider)) {
            return "Error: Only Stability.ai provider supported for image generation currently.";
        }
        if (apiKey == null || apiKey.isEmpty()) {
            return "Error: Stability.ai API Key not configured for image generation.";
        }

        String apiUrl = "https://api.stability.ai/v1/generation/" + model + "/text-to-image";

        Map<String, Object> body = Map.of(
                "text_prompts", List.of(Map.of("text", prompt)),
                "cfg_scale", 7,
                "height", 1024,
                "width", 1024,
                "samples", 1,
                "steps", 30
        );
        String json = JsonUtil.toJson(body);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .timeout(Duration.ofSeconds(60))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .build();

        HttpResponse<String> res = HttpClientProvider.get()
                .send(req, HttpResponse.BodyHandlers.ofString());

        if (res.statusCode() >= 200 && res.statusCode() < 300) {
            Map<String, Object> parsed = JsonUtil.fromJson(res.body());
            var artifacts = (List<?>) parsed.get("artifacts");
            if (artifacts != null && !artifacts.isEmpty()) {
                var firstArtifact = (Map<String, Object>) artifacts.get(0);
                String base64Image = (String) firstArtifact.get("base64");
                return "data:image/png;base64," + base64Image;
            }
            return "Sorry, no image artifact found.";
        } else {
            throw new RuntimeException("Stability.ai API error: " + res.statusCode() + " - " + res.body());
        }
    }
}
