package com.example.aichat.controller;

import com.example.aichat.db.ChatSessionDao;
import com.example.aichat.db.MessageDao;
import com.example.aichat.db.UserDao;
import com.example.aichat.model.ChatSession;
import com.example.aichat.model.Message;
import com.example.aichat.model.User;
import com.example.aichat.service.ApiException;
import com.example.aichat.service.ChatService;
import com.example.aichat.service.SettingsManager;
import com.example.aichat.service.SpeechToTextService;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatController {
    private enum ChatMode { TEXT, IMAGE_CREATION }

    @FXML private VBox messagesBox;
    @FXML private TextField inputField;
    @FXML private MenuItem createAccountMenuItem;
    @FXML private MenuItem loginMenuItem;
    @FXML private MenuItem logoutMenuItem;
    @FXML private HBox rootLayout;
    @FXML private ListView<ChatSession> chatHistoryList;
    @FXML private TextField searchChatField;
    @FXML private MenuButton userProfileMenuButton;
    @FXML private ImageView userProfileImageView;
    @FXML private Label userProfileNameLabel;
    @FXML private MenuItem changeProfilePhotoMenuItem;
    @FXML private MenuItem updateUsernameMenuItem;
    @FXML private MenuItem logoutProfileMenuItem;

    private Scene scene;
    private User currentUser;
    private SettingsManager settingsManager;
    private ChatSession currentSession;
    private ChatMode chatMode = ChatMode.TEXT;
    private boolean isListening = false;
    private SpeechToTextService speechToTextService;

    private final MessageDao messageDao = new MessageDao();
    private final ChatSessionDao chatSessionDao = new ChatSessionDao();
    private final UserDao userDao = new UserDao();
    private ChatService chatService;

    public void setScene(Scene scene) {
        this.scene = scene;
    }

    public void setSettingsManager(SettingsManager settingsManager) {
        this.settingsManager = settingsManager;
        this.chatService = new ChatService(settingsManager); // Initialize ChatService here
        applySettings();
        loadChatSessions(); // Load chat sessions after settingsManager is set
    }

    @FXML
    public void initialize() {
        setupChatHistoryContextMenu();
        // loadChatSessions() is now called in setSettingsManager()
        chatHistoryList.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                loadChatSession(newSelection);
            }
        });

        if (!chatHistoryList.getItems().isEmpty()) {
            chatHistoryList.getSelectionModel().selectFirst();
        } else {
            currentSession = null;
            messagesBox.getChildren().clear();
        }

        updateLoginStatusUI(null);

        searchChatField.textProperty().addListener((obs, oldText, newText) -> {
            filterChatSessions(newText);
        });

        // Add scroll event listener for zooming
        messagesBox.setOnScroll(this::handleScrollZoom);
        messagesBox.getStyleClass().add("messages-box"); // Apply CSS class to messagesBox
    }

    private void handleScrollZoom(ScrollEvent event) {
        if (!event.isControlDown()) { // Only zoom if Ctrl key is pressed
            return;
        }

        double zoomFactor = 1.05; // How much to zoom in/out
        double currentFontSize = Double.parseDouble(settingsManager.getProperty("messageFontSize").replace("px", ""));

        if (event.getDeltaY() > 0) { // Scroll up (zoom in)
            currentFontSize *= zoomFactor;
        } else { // Scroll down (zoom out)
            currentFontSize /= zoomFactor;
        }

        // Limit min/max font size
        currentFontSize = Math.max(10, currentFontSize); // Min 10px
        currentFontSize = Math.min(30, currentFontSize); // Max 30px

        settingsManager.setProperty("messageFontSize", String.format("%.0fpx", currentFontSize));
        settingsManager.saveSettings(); // Persist the new font size
        applyMessageFontSize(); // Apply to currently displayed messages
        event.consume(); // Prevent scroll from affecting ScrollPane
    }

    private void applyMessageFontSize() {
        String fontSize = settingsManager.getProperty("messageFontSize");
        for (javafx.scene.Node node : messagesBox.getChildren()) {
            if (node instanceof HBox) {
                HBox messageRow = (HBox) node;
                for (javafx.scene.Node child : messageRow.getChildren()) {
                    if (child instanceof TextArea) {
                        ((TextArea) child).setStyle("-fx-font-size: " + fontSize + ";");
                    } else if (child instanceof TextFlow) {
                        for (javafx.scene.Node textNode : ((TextFlow) child).getChildren()) {
                            if (textNode instanceof Text) {
                                ((Text) textNode).setStyle("-fx-font-size: " + fontSize + ";");
                            }
                        }
                    }
                }
            }
        }
    }


    private void filterChatSessions(String searchText) {
        if (searchText == null || searchText.isEmpty()) {
            loadChatSessions();
        } else {
            Integer userId = (currentUser != null) ? currentUser.getId() : null;
            List<ChatSession> filteredSessions = chatSessionDao.searchByTitle(searchText, userId);
            chatHistoryList.setItems(FXCollections.observableArrayList(filteredSessions));
        }
    }

    private void setupChatHistoryContextMenu() {
        ContextMenu contextMenu = new ContextMenu();
        MenuItem deleteItem = new MenuItem("Delete");
        deleteItem.setOnAction(event -> {
            ChatSession selectedSession = chatHistoryList.getSelectionModel().getSelectedItem();
            if (selectedSession != null) {
                deleteChatSession(selectedSession);
            }
        });
        contextMenu.getItems().add(deleteItem);

        chatHistoryList.setContextMenu(contextMenu);
    }

    private void deleteChatSession(ChatSession session) {
        messageDao.deleteBySessionId(session.getId());
        chatSessionDao.delete(session.getId());

        loadChatSessions();
        if (chatHistoryList.getItems().isEmpty()) {
            onNewChat();
        } else {
            chatHistoryList.getSelectionModel().selectFirst();
        }
    }

    @FXML
    public void onSend() {
        String userText = inputField.getText().trim();
        if (userText.isEmpty()) return;
        inputField.clear();

        appendAndPersist("user", userText);

        if (chatMode == ChatMode.IMAGE_CREATION) {
            CompletableFuture.supplyAsync(() -> {
                try {
                    return chatService.createImage(userText);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }).thenAccept(imageUrl -> {
                Platform.runLater(() -> {
                    if (imageUrl != null && !imageUrl.startsWith("Error:") && !imageUrl.startsWith("Sorry")) {
                        addImageBubble(imageUrl);
                    } else {
                        appendAndPersist("assistant", imageUrl);
                    }
                });
            }).exceptionally(this::handleAiServiceException);
            chatMode = ChatMode.TEXT;
            inputField.setPromptText("Type a message...");
        } else {
            List<Message> currentHistory = messageDao.findBySessionId(currentSession.getId());
            CompletableFuture.supplyAsync(() -> {
                try {
                    return chatService.ask(currentHistory, userText, null, null);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }).thenAccept(this::handleAssistantReply)
              .exceptionally(this::handleAiServiceException);
        }
    }

    @FXML
    public void onNewChat() {
        currentSession = null;
        messagesBox.getChildren().clear();
        chatHistoryList.getSelectionModel().clearSelection();
        chatMode = ChatMode.TEXT;
        inputField.setPromptText("Type a message...");
    }

    private void loadChatSessions() {
        Integer userId = (currentUser != null) ? currentUser.getId() : null;
        List<ChatSession> sessions = chatSessionDao.findAll(userId);
        chatHistoryList.setItems(FXCollections.observableArrayList(sessions));
    }

    private void loadChatSession(ChatSession session) {
        currentSession = session;
        messagesBox.getChildren().clear();
        List<Message> messages = messageDao.findBySessionId(session.getId());
        for (Message msg : messages) {
            addMessageBubble(msg.getRole(), msg.getContent());
        }
        chatMode = ChatMode.TEXT;
        inputField.setPromptText("Type a message...");
    }

    @FXML
    public void onCreateAccount() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/aichat/view/RegisterView.fxml"));
            Parent root = fxmlLoader.load();
            RegisterController registerController = fxmlLoader.getController();
            registerController.setChatController(this);

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Create Account");
            stage.setScene(new Scene(root));
            stage.showAndWait();
        } catch (IOException e) {
            System.err.println("Failed to load RegisterView.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void onLogin() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/aichat/view/LoginView.fxml"));
            Parent root = fxmlLoader.load();
            LoginController loginController = fxmlLoader.getController();
            Stage stage = new Stage();
            loginController.setStage(stage);
            loginController.setChatController(this);

            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Login");
            stage.setScene(new Scene(root));
            stage.showAndWait();
        } catch (IOException e) {
            System.err.println("Failed to load LoginView.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void onLogout() {
        currentUser = null;
        updateLoginStatusUI(null);
        System.out.println("User logged out.");
    }

    @FXML
    public void onOpenSettings() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/aichat/view/SettingsView.fxml"));
            Parent root = fxmlLoader.load();
            SettingsController settingsController = fxmlLoader.getController();
            settingsController.setSettingsManager(settingsManager);
            settingsController.setChatController(this);

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Settings");
            stage.setScene(new Scene(root));
            stage.showAndWait();
        } catch (IOException e) {
            System.err.println("Failed to load SettingsView.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void onAddPhoto() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );
        File selectedFile = fileChooser.showOpenDialog(scene.getWindow());
        if (selectedFile != null) {
            try {
                byte[] imageBytes = Files.readAllBytes(selectedFile.toPath());
                String mimeType = Files.probeContentType(selectedFile.toPath());

                // Display the image in the chat
                addImageBubble(selectedFile.toURI().toString());
                appendAndPersist("user", "Image uploaded: " + selectedFile.getName());

                // Ask the AI about the image
                List<Message> currentHistory = messageDao.findBySessionId(currentSession.getId());
                CompletableFuture.supplyAsync(() -> {
                    try {
                        return chatService.ask(currentHistory, "What do you see in this image?", imageBytes, mimeType);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }).thenAccept(this::handleAssistantReply)
                  .exceptionally(this::handleAiServiceException);

            } catch (IOException e) {
                System.err.println("Error reading image file: " + e.getMessage());
                appendAndPersist("assistant", "Error reading image file: " + e.getMessage());
            }
        }
    }

    @FXML
    public void onAddFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select File to Upload");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Text Files", "*.txt", "*.md", "*.java", "*.py", "*.c", "*.cpp", "*.h"),
                new FileChooser.ExtensionFilter("All Files", "*.*")
        );
        handleFileUpload(fileChooser, false);
    }

    @FXML
    public void onCreateImage() {
        chatMode = ChatMode.IMAGE_CREATION;
        inputField.setPromptText("Describe the image you want to create...");
        System.out.println("Switched to Image Creation mode.");
    }

    @FXML
    public void onVoiceInput() {
        if (isListening) {
            if (speechToTextService != null) {
                speechToTextService.stopRecordingAndTranscribe().thenAccept(transcript -> {
                    Platform.runLater(() -> {
                        inputField.setText(transcript);
                        inputField.setPromptText("Type a message...");
                        isListening = false;
                    });
                }).exceptionally(ex -> {
                    Platform.runLater(() -> {
                        System.err.println("Error during transcription: " + ex.getMessage());
                        inputField.setPromptText("Transcription error. Try again.");
                        isListening = false;
                    });
                    return null;
                });
            }
        } else {
            speechToTextService = new SpeechToTextService();
            try {
                speechToTextService.startRecording();
                inputField.setPromptText("Listening... Click mic to stop.");
                isListening = true;
            } catch (Exception e) {
                System.err.println("Failed to start voice input: " + e.getMessage());
                inputField.setPromptText("Mic error. Try again.");
                isListening = false;
            }
        }
    }

    @FXML
    public void onChangeProfilePhoto() {
        if (currentUser == null) return;
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Profile Photo");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );
        File selectedFile = fileChooser.showOpenDialog(scene.getWindow());
        if (selectedFile != null) {
            userProfileImageView.setImage(new Image(selectedFile.toURI().toString(), false));
        }
    }

    @FXML
    public void onUpdateUsername() {
        if (currentUser == null) return;
        TextInputDialog dialog = new TextInputDialog(currentUser.getUsername());
        dialog.setTitle("Update Username");
        dialog.setHeaderText("Enter your new username:");
        dialog.setContentText("Username:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(newName -> {
            if (!newName.isEmpty() && !newName.equals(currentUser.getUsername())) {
                currentUser.setUsername(newName);
                userDao.updateUser(currentUser);
                updateLoginStatusUI(currentUser);
            }
        });
    }

    private void handleFileUpload(FileChooser fileChooser, boolean isImage) {
        if (currentSession == null) {
            String initialTitle = isImage ? "Chat with Image" : "Chat with File";
            Integer userId = (currentUser != null) ? currentUser.getId() : null;
            currentSession = chatSessionDao.create(new ChatSession(initialTitle, userId));
            loadChatSessions();
            chatHistoryList.getSelectionModel().select(currentSession);
        }

        File selectedFile = fileChooser.showOpenDialog(scene.getWindow());

        if (selectedFile != null) {
            try {
                if (isImage) {
                    String imageUrl = selectedFile.toURI().toURL().toExternalForm();
                    addImageBubble(imageUrl);
                    String userMessage = "User uploaded an image: " + selectedFile.getName();
                    appendAndPersist("user", userMessage);
                    sendTextToAI(userMessage);
                } else {
                    String fileContent = Files.readString(selectedFile.toPath());
                    String userMessage = "Uploaded file: " + selectedFile.getName() + "\n\n" + fileContent;
                    appendAndPersist("user", userMessage);
                    sendTextToAI(fileContent);
                }
            } catch (IOException e) {
                System.err.println("Error reading file: " + e.getMessage());
                appendAndPersist("assistant", "Error reading file: " + e.getMessage());
            }
        } else {
            System.out.println("File selection cancelled.");
        }
    }

    private void sendTextToAI(String text) {
        List<Message> currentHistory = messageDao.findBySessionId(currentSession.getId());
        CompletableFuture.supplyAsync(() -> {
            try {
                return chatService.ask(currentHistory, text, null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).thenAccept(this::handleAssistantReply)
          .exceptionally(this::handleAiServiceException);
    }

    private void handleAssistantReply(String reply) {
        appendAndPersist("assistant", reply);
    }

    private Void handleAiServiceException(Throwable ex) {
        String errorMessage;
        Throwable cause = ex.getCause();

        if (cause instanceof ApiException) {
            ApiException apiEx = (ApiException) cause;
            if (apiEx.getStatusCode() == 402) {
                errorMessage = "API Error: Insufficient credits. Please check your account balance and upgrade if necessary.";
            } else {
                errorMessage = "API Error: " + apiEx.getStatusCode() + ". Please check your settings and try again.";
            }
        } else if (cause instanceof java.net.ConnectException || cause instanceof java.nio.channels.UnresolvedAddressException) {
            errorMessage = "Connection Error: Could not connect to the AI service. Please check your network connection and the host address in the settings.";
        } else if (cause instanceof java.net.http.HttpTimeoutException) {
            errorMessage = "Connection Timeout: The request to the AI service timed out.";
        } else {
            errorMessage = "An unexpected error occurred: " + (cause != null ? cause.getMessage() : ex.getMessage());
        }

        ex.printStackTrace();
        Platform.runLater(() -> appendAndPersist("assistant", errorMessage));
        return null;
    }

    private void appendAndPersist(String role, String content) {
        if (currentSession == null) {
            String title = content.length() > 30 ? content.substring(0, 30) + "..." : content;
            Integer userId = (currentUser != null) ? currentUser.getId() : null;
            currentSession = chatSessionDao.create(new ChatSession(title, userId));
            loadChatSessions();
            chatHistoryList.getSelectionModel().select(currentSession);
        }
        messageDao.insert(new Message(role, content), currentSession.getId());
        Platform.runLater(() -> addMessageBubble(role, content));
    }

    private void addMessageBubble(String role, String content) {
        HBox messageRow = new HBox();
        messageRow.setPadding(new Insets(2, 10, 2, 10));

        String messageFontSize = settingsManager.getProperty("messageFontSize");

        if ("user".equals(role)) {
            TextArea messageArea = new TextArea(content);
            messageArea.setEditable(false);
            messageArea.setWrapText(true);
            messageArea.setMaxWidth(600);
            messageArea.setPrefRowCount(3);
            messageArea.getStyleClass().add("user-message-bubble");
            messageArea.setStyle("-fx-font-size: " + messageFontSize + ";");

            ContextMenu contextMenu = new ContextMenu();
            MenuItem copyMenuItem = new MenuItem("Copy");
            copyMenuItem.setOnAction(event -> {
                Clipboard clipboard = Clipboard.getSystemClipboard();
                ClipboardContent clipboardContent = new ClipboardContent();
                String selectedText = messageArea.getSelectedText();
                clipboardContent.putString(selectedText != null && !selectedText.isEmpty() ? selectedText : messageArea.getText());
                clipboard.setContent(clipboardContent);
            });
            contextMenu.getItems().add(copyMenuItem);
            messageArea.setContextMenu(contextMenu);

            messageRow.setAlignment(Pos.CENTER_RIGHT);
            messageRow.getChildren().add(messageArea);
        } else {
            // Assistant message
            VBox assistantContainer = new VBox(5);
            assistantContainer.setAlignment(Pos.CENTER_LEFT);

            String remainingContent = content;

            // 1. Parse for Title
            Pattern titlePattern = Pattern.compile("^(\\*\\*.*?\\*\\*|#\\s+.*)\\s*\\n");
            Matcher titleMatcher = titlePattern.matcher(remainingContent);
            if (titleMatcher.find()) {
                String titleText = titleMatcher.group(1).replaceAll("[*#]", "").trim();
                Label titleLabel = new Label(titleText);
                titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 1.2em;");
                assistantContainer.getChildren().add(titleLabel);
                remainingContent = remainingContent.substring(titleMatcher.end());
            }

            // 2. Parse for Code Blocks and Text
            Pattern codeBlockPattern = Pattern.compile("```(.*?)\\n(.*?)\\n```", Pattern.DOTALL);
            Matcher codeMatcher = codeBlockPattern.matcher(remainingContent);
            int lastIndex = 0;

            while (codeMatcher.find()) {
                // Add text before the code block
                if (codeMatcher.start() > lastIndex) {
                    addFormattedText(assistantContainer, remainingContent.substring(lastIndex, codeMatcher.start()), messageFontSize);
                }

                // Add the code block
                String code = codeMatcher.group(2);
                TextArea codeArea = new TextArea(code);
                codeArea.setEditable(false);
                codeArea.setWrapText(false);
                
                int lineCount = code.split("\n").length;
                codeArea.setPrefRowCount(Math.min(lineCount, 25)); // Max 25 rows

                codeArea.setStyle(
                        "-fx-font-family: 'Consolas', 'Monospaced', monospace;" +
                        "-fx-font-size: 13px;" +
                        "-fx-control-inner-background: #1e1e1e;" +
                        "-fx-text-fill: #d4d4d4;" +
                        "-fx-border-color: black;" +
                        "-fx-border-width: 1;" +
                        "-fx-border-radius: 4;"
                );
                assistantContainer.getChildren().add(codeArea);
                lastIndex = codeMatcher.end();
            }

            // Add any remaining text after the last code block
            if (lastIndex < remainingContent.length()) {
                addFormattedText(assistantContainer, remainingContent.substring(lastIndex), messageFontSize);
            }
            
            // If no content was added at all (e.g., empty response), add the original content
            if (assistantContainer.getChildren().isEmpty()) {
                 addFormattedText(assistantContainer, content, messageFontSize);
            }

            messageRow.setAlignment(Pos.CENTER_LEFT);
            messageRow.getChildren().add(assistantContainer);
        }
        messagesBox.getChildren().add(messageRow);
    }

    private void addFormattedText(VBox container, String text, String fontSize) {
        if (text.trim().isEmpty()) return;

        TextFlow textFlow = new TextFlow();
        textFlow.setMaxWidth(600);
        textFlow.getStyleClass().add("assistant-message-bubble");

        Pattern boldPattern = Pattern.compile("\\*\\*(.*?)\\*\\*");
        String[] paragraphs = text.split("\n");

        for (int i = 0; i < paragraphs.length; i++) {
            String paragraph = paragraphs[i];
            Matcher matcher = boldPattern.matcher(paragraph);
            int lastIndex = 0;

            while (matcher.find()) {
                if (matcher.start() > lastIndex) {
                    Text regularText = new Text(paragraph.substring(lastIndex, matcher.start()));
                    regularText.setStyle("-fx-font-size: " + fontSize + ";");
                    textFlow.getChildren().add(regularText);
                }
                Text boldText = new Text(matcher.group(1));
                boldText.setStyle("-fx-font-weight: bold; -fx-font-size: " + fontSize + ";");
                textFlow.getChildren().add(boldText);
                lastIndex = matcher.end();
            }
            if (lastIndex < paragraph.length()) {
                Text regularText = new Text(paragraph.substring(lastIndex));
                regularText.setStyle("-fx-font-size: " + fontSize + ";");
                textFlow.getChildren().add(regularText);
            }

            if (i < paragraphs.length - 1) {
                textFlow.getChildren().add(new Text("\n"));
            }
        }

        ContextMenu contextMenu = new ContextMenu();
        MenuItem copyMenuItem = new MenuItem("Copy");
        copyMenuItem.setOnAction(event -> {
            Clipboard clipboard = Clipboard.getSystemClipboard();
            ClipboardContent clipboardContent = new ClipboardContent();
            clipboardContent.putString(text);
            clipboard.setContent(clipboardContent);
        });
        contextMenu.getItems().add(copyMenuItem);
        textFlow.setOnContextMenuRequested(event -> {
            contextMenu.show(textFlow, event.getScreenX(), event.getScreenY());
            event.consume();
        });

        container.getChildren().add(textFlow);
    }


    private void addImageBubble(String imageUrl) {
        ImageView imageView = new ImageView(new Image(imageUrl, true));
        imageView.setFitWidth(400);
        imageView.setPreserveRatio(true);

        HBox imageContainer = new HBox(imageView);
        imageContainer.setPadding(new Insets(5, 10, 5, 10));
        imageContainer.setAlignment(Pos.CENTER_LEFT);

        messagesBox.getChildren().add(imageContainer);
    }

    public void onUserLoggedIn(User user) {
        this.currentUser = user;
        updateLoginStatusUI(user);
        loadChatSessions();
    }

    private void updateLoginStatusUI(User user) {
        if (user != null) {
            createAccountMenuItem.setVisible(false);
            loginMenuItem.setVisible(false);
            logoutMenuItem.setVisible(true);
            userProfileMenuButton.setVisible(true);
            userProfileNameLabel.setText(user.getUsername());
            userProfileImageView.setImage(new Image("https://via.placeholder.com/30", false));
            updateUsernameMenuItem.setStyle("-fx-text-fill: #007bff;");
            logoutProfileMenuItem.setStyle("-fx-text-fill: red;");
        } else {
            createAccountMenuItem.setVisible(true);
            loginMenuItem.setVisible(true);
            logoutMenuItem.setVisible(false);
            userProfileMenuButton.setVisible(true);
            userProfileNameLabel.setText("Guest");
            userProfileImageView.setImage(new Image("https://via.placeholder.com/30/808080?text=G", false));
            updateUsernameMenuItem.setStyle("");
            logoutProfileMenuItem.setStyle("");
        }
    }

    public void applySettings() {
        if (settingsManager == null) return;

        this.chatService = new ChatService(settingsManager);

        if (scene == null) return;

        String theme = settingsManager.getProperty("theme");
        scene.getStylesheets().clear();
        if ("Dark".equalsIgnoreCase(theme)) {
            scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/com/example/aichat/css/dark-theme.css")).toExternalForm());
        } else {
            scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/com/example/aichat/css/light-theme.css")).toExternalForm());
        }

        String fontSize = settingsManager.getProperty("fontSize");
        String fontFamily = settingsManager.getProperty("fontFamily");
        if (rootLayout != null) {
            rootLayout.setStyle("-fx-font-size: " + fontSize + "; -fx-font-family: '" + fontFamily + "';");
        }
        applyMessageFontSize(); // Apply message font size on settings change
    }
}
