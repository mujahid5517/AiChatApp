package com.example.aichat.controller;

import com.example.aichat.service.ChatService;
import com.example.aichat.service.SettingsManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettingsController {

    @FXML private ChoiceBox<String> themeChoice;
    @FXML private ChoiceBox<String> fontSizeChoice;
    @FXML private ComboBox<String> fontFamilyCombo;
    @FXML private ChoiceBox<String> providerChoice;
    @FXML private ChoiceBox<String> modelChoice;
    @FXML private TextField googleApiKeyField;
    @FXML private TextField openRouterKey;
    @FXML private TextField groqKey;
    @FXML private TextField ollamaHost;
    @FXML private TextField stabilityApiKeyField;
    @FXML private HBox googleApiKeyBox;
    @FXML private HBox openRouterKeyBox;
    @FXML private HBox groqKeyBox;
    @FXML private HBox ollamaHostBox;
    @FXML private HBox stabilityApiKeyBox;

    private SettingsManager settingsManager;
    private ChatController chatController;
    private ChatService chatService;

    private final Map<String, List<String>> providerModels = new HashMap<>();

    public void setSettingsManager(SettingsManager settingsManager) {
        this.settingsManager = settingsManager;
        this.chatService = new ChatService(settingsManager); // Initialize ChatService
        loadSettings();
    }

    public void setChatController(ChatController chatController) {
        this.chatController = chatController;
    }

    @FXML
    public void initialize() {
        themeChoice.setItems(FXCollections.observableArrayList("Light", "Dark"));
        fontSizeChoice.setItems(FXCollections.observableArrayList("12px", "14px", "16px", "18px"));
        fontFamilyCombo.setItems(FXCollections.observableArrayList(Font.getFamilies()));

        // Static models for other providers
        providerModels.put("Google", Arrays.asList("gemini-1.0-pro", "gemini-1.5-flash", "gemini-pro"));
        providerModels.put("OpenRouter", Arrays.asList("deepseek/deepseek-r1", "openai/gpt-4o", "mistralai/mistral-7b-instruct", "google/gemini-pro"));
        providerModels.put("Groq", Arrays.asList("llama3-8b-8192", "mixtral-8x7b-32768"));
        providerModels.put("Ollama", Arrays.asList()); // Add Ollama to the map
        providerModels.put("Stability.ai", Arrays.asList("stable-diffusion-v1-6", "stable-diffusion-xl-1024-v1-0"));

        providerChoice.setItems(FXCollections.observableArrayList(providerModels.keySet()));

        providerChoice.getSelectionModel().selectedItemProperty().addListener((obs, oldProvider, newProvider) -> {
            if (newProvider != null) {
                if ("Ollama".equals(newProvider)) {
                    // Dynamically fetch Ollama models
                    List<String> ollamaModels = chatService.listOllamaModels();
                    modelChoice.setItems(FXCollections.observableArrayList(ollamaModels));
                } else {
                    modelChoice.setItems(FXCollections.observableArrayList(providerModels.get(newProvider)));
                }

                String savedModel = settingsManager.getProperty("model");
                if (savedModel != null && modelChoice.getItems().contains(savedModel)) {
                    modelChoice.setValue(savedModel);
                } else if (!modelChoice.getItems().isEmpty()) {
                    modelChoice.setValue(modelChoice.getItems().get(0));
                }
                updateApiKeyFieldsVisibility(newProvider);
            } else {
                modelChoice.setItems(FXCollections.observableArrayList());
                updateApiKeyFieldsVisibility(null);
            }
        });
    }

    private void loadSettings() {
        if (settingsManager != null) {
            themeChoice.setValue(settingsManager.getProperty("theme"));
            fontSizeChoice.setValue(settingsManager.getProperty("fontSize"));
            fontFamilyCombo.setValue(settingsManager.getProperty("fontFamily"));
            
            String savedProvider = settingsManager.getProperty("provider");
            // Check if savedProvider is in the keyset before setting
            if (savedProvider != null && providerModels.containsKey(savedProvider)) {
                providerChoice.setValue(savedProvider);
            } else {
                providerChoice.setValue("Google"); // Default provider
            }

            googleApiKeyField.setText(settingsManager.getProperty("googleApiKey"));
            openRouterKey.setText(settingsManager.getProperty("openRouterKey"));
            groqKey.setText(settingsManager.getProperty("groqKey"));
            ollamaHost.setText(settingsManager.getProperty("ollamaHost"));
            stabilityApiKeyField.setText(settingsManager.getProperty("stabilityApiKey"));
        }
    }

    private void updateApiKeyFieldsVisibility(String provider) {
        googleApiKeyBox.setVisible("Google".equals(provider));
        openRouterKeyBox.setVisible("OpenRouter".equals(provider));
        groqKeyBox.setVisible("Groq".equals(provider));
        ollamaHostBox.setVisible("Ollama".equals(provider));
        stabilityApiKeyBox.setVisible("Stability.ai".equals(provider));
    }

    @FXML
    private void onSave() {
        if (settingsManager != null) {
            settingsManager.setProperty("theme", themeChoice.getValue() != null ? themeChoice.getValue() : "Light");
            settingsManager.setProperty("fontSize", fontSizeChoice.getValue() != null ? fontSizeChoice.getValue() : "14px");
            settingsManager.setProperty("fontFamily", fontFamilyCombo.getValue() != null ? fontFamilyCombo.getValue() : "System");
            settingsManager.setProperty("provider", providerChoice.getValue() != null ? providerChoice.getValue() : "Google");
            settingsManager.setProperty("model", modelChoice.getValue() != null ? modelChoice.getValue() : "gemini-1.0-pro");
            settingsManager.setProperty("googleApiKey", googleApiKeyField.getText() != null ? googleApiKeyField.getText() : "");
            settingsManager.setProperty("openRouterKey", openRouterKey.getText() != null ? openRouterKey.getText() : "");
            settingsManager.setProperty("groqKey", groqKey.getText() != null ? groqKey.getText() : "");
            settingsManager.setProperty("ollamaHost", ollamaHost.getText() != null ? ollamaHost.getText() : "");
            settingsManager.setProperty("stabilityApiKey", stabilityApiKeyField.getText() != null ? stabilityApiKeyField.getText() : "");

            settingsManager.saveSettings();

            if (chatController != null) {
                chatController.applySettings();
            }
        }
        closeWindow();
    }

    @FXML
    private void onCancel() {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) themeChoice.getScene().getWindow();
        stage.close();
    }
}
