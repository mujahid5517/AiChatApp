package com.example.aichat.controller;

import com.example.aichat.db.UserDao;
import com.example.aichat.model.User;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.util.List;
import java.util.stream.Collectors;

public class DashboardController {

    @FXML private Label chatGptLabel;
    @FXML private Button upgradeToGoButton;
    @FXML private TextField askAnythingField;
    @FXML private Label usernameLabel;
    @FXML private Label statusLabel;
    @FXML private Button upgradeButton;
    @FXML private Label avatarInitialLabel;
    @FXML private ListView<String> userListView; // Added user list view

    private final UserDao userDao = new UserDao();

    @FXML
    public void initialize() {
        // Load and display all users
        loadAllUsers();
    }

    private void loadAllUsers() {
        List<User> users = userDao.findAll();
        List<String> usernames = users.stream()
                .map(User::getUsername)
                .collect(Collectors.toList());
        userListView.setItems(FXCollections.observableArrayList(usernames));
    }

    public void setUserInfo(User user) {
        if (user != null) {
            usernameLabel.setText(user.getUsername());
            statusLabel.setText("Logged In (Email: " + user.getEmail() + ")");
            if (user.getUsername() != null && !user.getUsername().isEmpty()) {
                avatarInitialLabel.setText(String.valueOf(user.getUsername().charAt(0)).toUpperCase());
            } else {
                avatarInitialLabel.setText("?");
            }
        }
    }

    @FXML
    private void onUpgradeToGo() {
        System.out.println("Upgrade to Go button clicked!");
    }

    @FXML
    private void onAskAnything() {
        System.out.println("Ask anything field entered!");
    }

    @FXML
    private void onUpgrade() {
        System.out.println("Upgrade button clicked!");
    }
}
