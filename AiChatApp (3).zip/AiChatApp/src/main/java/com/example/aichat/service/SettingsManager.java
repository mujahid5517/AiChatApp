package com.example.aichat.service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class SettingsManager {
    private final Properties properties;
    private final String settingsFilePath = "settings.properties";

    public SettingsManager() {
        // 1. Create a Properties object for the defaults
        Properties defaultProps = new Properties();
        setDefaultProperties(defaultProps);

        // 2. Create the main properties object with the defaults as a fallback
        properties = new Properties(defaultProps);

        // 3. Load the user's settings from the file, which will override defaults if present
        loadUserSettings();
    }

    private void setDefaultProperties(Properties props) {
        props.setProperty("theme", "Light");
        props.setProperty("fontSize", "14px");
        props.setProperty("fontFamily", "System");
        props.setProperty("messageFontSize", "14px"); // New default message font size
        props.setProperty("provider", "Google");
        props.setProperty("model", "gemini-1.0-pro");
        props.setProperty("googleApiKey", "AIzaSyDKa3qtJxjeKHT0HXlT6PR7RomP4L6V4eU");
        props.setProperty("openRouterKey", "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");
        props.setProperty("groqKey", "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");
        props.setProperty("ollamaHost", "http://localhost:11434");
        props.setProperty("stabilityApiKey", "sk-s24dJSolwfWR4CDuWy41Q9pPhYuykCoFRUgqQnJF4DjH5QfQ");
    }

    private void loadUserSettings() {
        try (FileInputStream in = new FileInputStream(settingsFilePath)) {
            properties.load(in);
        } catch (IOException e) {
            // If the file doesn't exist, it's fine. The defaults will be used.
            System.out.println("No settings file found, using default settings.");
        }
    }

    public void saveSettings() {
        try (FileOutputStream out = new FileOutputStream(settingsFilePath)) {
            properties.store(out, "AI Chat App Settings");
        } catch (IOException e) {
            System.err.println("Error saving settings: " + e.getMessage());
        }
    }

    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    public void setProperty(String key, String value) {
        properties.setProperty(key, value);
    }
}
