package com.example.aichat;

import com.example.aichat.controller.ChatController;
import com.example.aichat.service.SettingsManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        SettingsManager settingsManager = new SettingsManager(); // Create SettingsManager

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ChatView.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 800, 600);

        // Apply theme from settings
        String theme = settingsManager.getProperty("theme");
        if ("Dark".equalsIgnoreCase(theme)) {
            scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("css/dark-theme.css")).toExternalForm());
        } else {
            scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("css/light-theme.css")).toExternalForm());
        }

        // Get the controller and pass the scene and settingsManager to it
        ChatController controller = fxmlLoader.getController();
        controller.setScene(scene);
        controller.setSettingsManager(settingsManager); // Pass SettingsManager

        stage.setTitle("AI Chat");
        stage.setScene(scene);
        stage.show();
    }
}
