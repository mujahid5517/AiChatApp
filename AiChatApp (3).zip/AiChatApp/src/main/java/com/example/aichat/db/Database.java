package com.example.aichat.db;

import java.sql.*;

public class Database {
    private static final String DB_URL = "jdbc:sqlite:aichat.db";

    static {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement st = conn.createStatement()) {

            // Create users table first, as chat_sessions depends on it
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS users (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT NOT NULL UNIQUE,
                  email TEXT NOT NULL UNIQUE,
                  password_hash TEXT NOT NULL,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """);

            // Create chat_sessions table
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS chat_sessions (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  title TEXT NOT NULL,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  user_id INTEGER,
                  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                )
            """);

            // Check if user_id column exists in chat_sessions table and add if not (for older databases)
            boolean userIdColumnExists = false;
            try (ResultSet rs = conn.getMetaData().getColumns(null, null, "chat_sessions", "user_id")) {
                if (rs.next()) {
                    userIdColumnExists = true;
                }
            }

            if (!userIdColumnExists) {
                st.executeUpdate("ALTER TABLE chat_sessions ADD COLUMN user_id INTEGER");
            }

            // Create messages table
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS messages (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  role TEXT NOT NULL,
                  content TEXT NOT NULL,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  session_id INTEGER,
                  FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE
                )
            """);

            // Check if session_id column exists in messages table and add if not (for older databases)
            boolean sessionIdColumnExists = false;
            try (ResultSet rs = conn.getMetaData().getColumns(null, null, "messages", "session_id")) {
                if (rs.next()) {
                    sessionIdColumnExists = true;
                }
            }

            if (!sessionIdColumnExists) {
                st.executeUpdate("ALTER TABLE messages ADD COLUMN session_id INTEGER");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize database", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }
}
